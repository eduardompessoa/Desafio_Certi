Testes de API - Arquivos e instruções

Este repositório contém os materiais produzidos durante a realização dos teste Testes de API:

 3 casos de teste que você considera básicos:
 Get - Listar Produtos;
 Get - Buscar produto por ID;
 Post - Criar Usuário;

 3 casos de teste que você considera intermediários:
 Put - Atualizar Produto;
 Delete - Remover Produto;
 Get - Produtos por Categoria;
 
 3 casos de teste que você considera avançados:
 Post - Login;
 Post - Criar Carrinho;
 Get - Listar Carrinho;
 Put - Atualizar Carrinho;

 Instruções:
 
  - Importar o aquivo: FakeStoreAPI Collection.postman_collection.Json na ferramenta Postman;
  - As evidencias de cada teste estão na pasta: Evidencias;




