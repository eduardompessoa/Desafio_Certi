Teste Exploratóro – Documentação e Evidências

Este repositório contém os materiais produzidos durante a realização do teste exploratório. Foram elaborados dois arquivos principais:

Um arquivo em PDF: Texte_Exploratorio. Para o mesmo documento existe a versão em excel, caso ocorra algum problema de visualização.


Evidências e Descrição dos Problemas

Todas as descrições dos problemas encontrados durante o teste estão documentadas no arquivo:

Evidencias_teste_exploratorio

Além disso, as imagens dos bugs identificados podem ser consultadas dentro da pasta:

/evidencia

Essa pasta contém capturas de tela coletadas durante os testes. Imagens essas também presentes dentro do arquivo: Evidencias_teste_exploratorio.