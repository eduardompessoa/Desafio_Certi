Casos de teste Web – Documentação

Este repositório contém os materiais gerados para execução de casos de teste Web:

Arquivos Incluídos

PDF com o Descrição dos casos de testes: Casos_de_Teste. Arquivo esse possui sua versão Word, caso aconteça problemas de visualização.

Foram utilizados cards de passo a passo para cada teste, abrangendo parte funcional com teste de caixa-preta, sem nenhum acesso ao código fonte da pagina Web.


